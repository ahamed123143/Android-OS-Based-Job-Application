package com.example.items;

public class CatItems {

    private int CatId;
    private String CatName;
    private String CatImgUrl;

    public void setCatId(int catId) {
        CatId = catId;
    }

    public void setCatName(String catName) {
        CatName = catName;
    }

    public void setCatImgUrl(String catImgUrl) {
        CatImgUrl = catImgUrl;
    }

    public int getCatId() {
        return CatId;
    }

    public String getCatName() {
        return CatName;
    }

    public String getCatImgUrl() {
        return CatImgUrl;
    }
}
