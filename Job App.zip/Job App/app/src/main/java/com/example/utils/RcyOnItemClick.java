package com.example.utils;

public interface RcyOnItemClick {
    void onItemClick(int position);
}
