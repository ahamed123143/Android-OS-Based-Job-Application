package com.example.items;

public class SeekerUser {

    private int id;
    private String usertype;
    private String username;
    private String email;
    private String password;
    private String phone;
    private String city;
    private String address;
    private String image;
    private String resume;
    private String current_company;
    private String experience;
    private String skills;
    private String gender;
    private String dob;

    public SeekerUser(int id,String userType, String userName, String email, String password, String phone,String city, String address, String currentCompany, String experience,String skills, String gender ) {
        this.usertype = userType;
        this.username = userName;
        this.email = email;
        this.password = password;
        this.phone = phone;
        this.city = city;
        this.address = address;
        this.current_company = currentCompany;
        this.experience = experience;
        this.skills = skills;
        this.gender = gender;
        this.id = id;
    }



    public SeekerUser(String usertype, String username, String email,String password, String phone){
        this.usertype = usertype;
        this.username = username;
        this.email = email;
        this.phone = phone;
        this.password = password;

    }
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsertype() {
        return usertype;
    }

    public void setUsertype(String usertype) {
        this.usertype = usertype;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getResume() {
        return resume;
    }

    public void setResume(String resume) {
        this.resume = resume;
    }

    public String getCurrent_company() {
        return current_company;
    }

    public void setCurrent_company(String current_company) {
        this.current_company = current_company;
    }

    public String getExperience() {
        return experience;
    }

    public void setExperience(String experience) {
        this.experience = experience;
    }

    public String getSkills() {
        return skills;
    }

    public void setSkills(String skills) {
        this.skills = skills;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }
}
