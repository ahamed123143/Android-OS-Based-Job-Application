package com.example.utils.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.items.SeekerUser;

public class DatabaseHelper extends SQLiteOpenHelper {

    //Database Name
    private static final String DB_NAME ="mydb";

    //Table Name
    private static final String USER_TABLE = "user_table";

    //User Table Column Name
    private static final String USER_ID = "id";
    private static final String USER_TYPE = "user_type";
    private static final String NAME = "user_name";
    private static final String EMAIL = "user_email";
    private static final String PASSWORD = "user_password";
    private static final String PHONE = "user_phone";
    private static final String CITY = "user_city";
    private static final String ADDRESS = "user_address";
    private static final String IMAGE = "user_image";
    private static final String RESUME = "user_resume";
    private static final String CURRENT_COMPANY_NAME = "user_current_company";
    private static final String EXPERIENCE = "user_experience";
    private static final String SKILLS = "user_skills";
    private static final String GENDER = "user_gender";
    private static final String DATE_OF_BIRTH = "user_dob";
    private static final String REGISTER_DATE = "user_reg_date";

    //Create Table Statement
    private static final String CREATE_USER_TABLE = "CREATE TABLE " + USER_TABLE + " ("
                                                    + USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                                                    + USER_TYPE + " TEXT,"
                                                    + NAME + " TEXT,"
                                                    + EMAIL + " TEXT unique,"
                                                    + PASSWORD + " TEXT,"
                                                    + PHONE + " TEXT,"
                                                    + CITY + " TEXT,"
                                                    + ADDRESS + " TEXT,"
                                                    + CURRENT_COMPANY_NAME + " TEXT,"
                                                    + EXPERIENCE + " TEXT,"
                                                    + SKILLS + " TEXT,"
                                                    + GENDER + " TEXT)";


    public DatabaseHelper (Context context){
        super(context, DB_NAME, null, 1);

    }

    @Override
    public void onCreate(SQLiteDatabase MyDB) {
           MyDB.execSQL(CREATE_USER_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase MyDB, int i, int i1) {
        MyDB.execSQL("DROP TABLE IF EXISTS " + USER_TABLE);
        onCreate(MyDB);
    }


    public long addUser(SeekerUser user,Context context ){
     SQLiteDatabase db = this.getWritableDatabase();
     ContentValues values = new ContentValues();
     values.put(USER_TYPE,user.getUsertype());
     values.put(NAME,user.getUsername());
     values.put(EMAIL,user.getEmail());
     values.put(PASSWORD,user.getPassword());
     values.put(PHONE,user.getPhone());
     values.put(CITY,user.getCity());
     values.put(ADDRESS,user.getAddress());
     values.put(CURRENT_COMPANY_NAME,user.getCurrent_company());
     values.put(EXPERIENCE,user.getExperience());
     values.put(SKILLS,user.getSkills());
     values.put(GENDER,user.getGender());

     return   db.insert(USER_TABLE, null, values);

    }

    public long updateUsername(String uName,String email){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(NAME,uName);
        return  db.update(USER_TABLE, values,"user_email = ?", new String[]{email});
    }

    public long updateUser(SeekerUser user,Context context,int id ){
        String unique_id = Integer.toString(id);
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(USER_TYPE,user.getUsertype());
        values.put(NAME,user.getUsername());
        values.put(EMAIL,user.getEmail());
        values.put(PASSWORD,user.getPassword());
        values.put(PHONE,user.getPhone());
        values.put(CITY,user.getCity());
        values.put(ADDRESS,user.getPhone());
        values.put(CURRENT_COMPANY_NAME,user.getCurrent_company());
        values.put(EXPERIENCE,user.getExperience());
        values.put(GENDER,user.getGender());

        return   db.update(USER_TABLE, values,"id = ?", new String[]{unique_id});

    }




    public SeekerUser getUserDetails(String email,Context context){

            String qry = "SELECT * FROM user_table WHERE user_email = '" + email+"'";
            SQLiteDatabase db = this.getReadableDatabase();
            SeekerUser userDetails = null;
            Cursor cursor = db.rawQuery(qry, null);
                if (cursor != null) {
                    cursor.moveToFirst();
                    int id = cursor.getInt(0);
                    String usertype = cursor.getString(1);
                    String username = cursor.getString(2);
                    String userEmail = cursor.getString(3);
                    String password = cursor.getString(4);
                    String userPhone = cursor.getString(5);
                    String userCity = cursor.getString(6);
                    String address = cursor.getString(7);
                    String currentCompany = cursor.getString(8);
                    String experience = cursor.getString(9);
                    String skills = cursor.getString(10);
                    String gender = cursor.getString(11);
                    userDetails = new SeekerUser(id,usertype,username,userEmail,password,userPhone,userCity,address,currentCompany,experience,skills,gender);
                }



         return  userDetails;
    }
    public boolean checkUserAvailable(String email){
        String qry = "SELECT * FROM user_table WHERE user_email = '" + email+"'";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(qry, null);
        if(cursor !=null){
            return true;
        }
        else{
            return false;
        }
    }



}
