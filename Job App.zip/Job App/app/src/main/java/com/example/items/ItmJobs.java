package com.example.items;

import android.os.Parcel;
import android.os.Parcelable;

public class ItmJobs implements Parcelable {
    private String id;
    private String jobName;
    private String jobDesignation;
    private String jobDesc;
    private String jobSalary;
    private String jobCompanyName;
    private String jobCompanyWebsite;
    private String jobPhoneNumber;
    private String jobMail;
    private String jobVacancy;
    private String jobAddress;
    private String jobQualification;
    private String jobSkill;
    private String jobImage;
    private String jobDate;
    private String jobApplyTotal;
    private String jobCategoryName;
    private String jobAppliedDate;
    private String jobType;
    private String jobWorkDay;
    private String jobWorkTime;
    private String jobExperience;
    private boolean isJobSeen = false;
    private boolean isJobFavourite = false;

    public ItmJobs(){

    }

    public ItmJobs(Parcel in) {
        id = in.readString();
        jobName = in.readString();
        jobDesignation = in.readString();
        jobDesc = in.readString();
        jobSalary = in.readString();
        jobCompanyName = in.readString();
        jobCompanyWebsite = in.readString();
        jobPhoneNumber = in.readString();
        jobMail = in.readString();
        jobVacancy = in.readString();
        jobAddress = in.readString();
        jobQualification = in.readString();
        jobSkill = in.readString();
        jobImage = in.readString();
        jobDate = in.readString();
        jobApplyTotal = in.readString();
        jobCategoryName = in.readString();
        jobAppliedDate = in.readString();
        jobType = in.readString();
        jobWorkDay = in.readString();
        jobWorkTime = in.readString();
        jobExperience = in.readString();
        isJobSeen = in.readByte() != 0;
        isJobFavourite = in.readByte() != 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeString(jobName);
        dest.writeString(jobDesignation);
        dest.writeString(jobDesc);
        dest.writeString(jobSalary);
        dest.writeString(jobCompanyName);
        dest.writeString(jobCompanyWebsite);
        dest.writeString(jobPhoneNumber);
        dest.writeString(jobMail);
        dest.writeString(jobVacancy);
        dest.writeString(jobAddress);
        dest.writeString(jobQualification);
        dest.writeString(jobSkill);
        dest.writeString(jobImage);
        dest.writeString(jobDate);
        dest.writeString(jobApplyTotal);
        dest.writeString(jobCategoryName);
        dest.writeString(jobAppliedDate);
        dest.writeString(jobType);
        dest.writeString(jobWorkDay);
        dest.writeString(jobWorkTime);
        dest.writeString(jobExperience);
        dest.writeByte((byte) (isJobSeen ? 1 : 0));
        dest.writeByte((byte) (isJobFavourite ? 1 : 0));
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<ItmJobs> CREATOR = new Creator<ItmJobs>() {
        @Override
        public ItmJobs createFromParcel(Parcel in) {
            return new ItmJobs(in);
        }

        @Override
        public ItmJobs[] newArray(int size) {
            return new ItmJobs[size];
        }
    };

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setJobName(String jobName) {
        this.jobName = jobName;
    }

    public String getJobName() {
        return jobName;
    }

    public String getJobDesignation() {
        return jobDesignation;
    }

    public void setJobDesignation(String jobDesignation) {
        this.jobDesignation = jobDesignation;
    }

    public String getJobDesc() {
        return jobDesc;
    }

    public void setJobDesc(String jobDesc) {
        this.jobDesc = jobDesc;
    }

    public String getJobSalary() {
        return jobSalary;
    }

    public void setJobSalary(String jobSalary) {
        this.jobSalary = jobSalary;
    }

    public String getJobCompanyName() {
        return jobCompanyName;
    }

    public void setJobCompanyName(String jobCompanyName) {
        this.jobCompanyName = jobCompanyName;
    }

    public String getJobCompanyWebsite() {
        return jobCompanyWebsite;
    }

    public void setJobCompanyWebsite(String jobCompanyWebsite) {
        this.jobCompanyWebsite = jobCompanyWebsite;
    }

    public String getJobPhoneNumber() {
        return jobPhoneNumber;
    }

    public void setJobPhoneNumber(String jobPhoneNumber) {
        this.jobPhoneNumber = jobPhoneNumber;
    }

    public String getJobMail() {
        return jobMail;
    }

    public void setJobMail(String jobMail) {
        this.jobMail = jobMail;
    }

    public String getJobVacancy() {
        return jobVacancy;
    }

    public void setJobVacancy(String jobVacancy) {
        this.jobVacancy = jobVacancy;
    }

    public String getJobAddress() {
        return jobAddress;
    }

    public void setJobAddress(String jobAddress) {
        this.jobAddress = jobAddress;
    }

    public String getJobQualification() {
        return jobQualification;
    }

    public void setJobQualification(String jobQualification) {
        this.jobQualification = jobQualification;
    }

    public String getJobSkill() {
        return jobSkill;
    }

    public void setJobSkill(String jobSkill) {
        this.jobSkill = jobSkill;
    }

    public String getJobImage() {
        return jobImage;
    }

    public void setJobImage(String jobImage) {
        this.jobImage = jobImage;
    }

    public String getJobDate() {
        return jobDate;
    }

    public void setJobDate(String jobDate) {
        this.jobDate = jobDate;
    }

    public String getJobApplyTotal() {
        return jobApplyTotal;
    }

    public void setJobApplyTotal(String jobApplyTotal) {
        this.jobApplyTotal = jobApplyTotal;
    }

    public String getJobCategoryName() {
        return jobCategoryName;
    }

    public void setJobCategoryName(String jobCategoryName) {
        this.jobCategoryName = jobCategoryName;
    }

    public String getJobAppliedDate() {
        return jobAppliedDate;
    }

    public void setJobAppliedDate(String jobAppliedDate) {
        this.jobAppliedDate = jobAppliedDate;
    }

    public boolean isJobSeen() {
        return isJobSeen;
    }

    public void setJobSeen(boolean jobSeen) {
        isJobSeen = jobSeen;
    }

    public String getJobType() {
        return jobType;
    }

    public void setJobType(String jobType) {
        this.jobType = jobType;
    }

    public boolean isJobFavourite() {
        return isJobFavourite;
    }

    public void setJobFavourite(boolean jobFavourite) {
        isJobFavourite = jobFavourite;
    }

    public String getJobWorkDay() {
        return jobWorkDay;
    }

    public void setJobWorkDay(String jobWorkDay) {
        this.jobWorkDay = jobWorkDay;
    }

    public String getJobWorkTime() {
        return jobWorkTime;
    }

    public void setJobWorkTime(String jobWorkTime) {
        this.jobWorkTime = jobWorkTime;
    }

    public String getJobExperience() {
        return jobExperience;
    }

    public void setJobExperience(String jobExperience) {
        this.jobExperience = jobExperience;
    }
}
