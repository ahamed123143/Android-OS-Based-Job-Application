package com.example.fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;

import com.college.londonjobs.R;
import com.example.adapters.CategoryAdapter;
import com.example.items.CatItems;
import com.example.utils.Utils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;


public class CategeoryFragment extends Fragment {

    ArrayList<CatItems> mCatListItem;
    public RecyclerView recyclerView;
    CategoryAdapter adapter;
    private ProgressBar progressBar;
    private LinearLayout layout_not_found;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.row_rcylview, container, false);
        layout_not_found = rootView.findViewById(R.id.layout_not_found);
        recyclerView = rootView.findViewById(R.id.vertical_courses_list);
        mCatListItem = new ArrayList<>();
        getCategory();
        Utils.toast(getActivity(),Integer.toString(mCatListItem.size()));
        // setting grid layout manager to implement grid view.
        // in this method '3' represents number of columns to be displayed in grid view.
        GridLayoutManager layoutManager=new GridLayoutManager(getActivity(),3);
        // at last set adapter to recycler view.
        recyclerView.setLayoutManager(layoutManager);
        adapter=new CategoryAdapter(getActivity(),mCatListItem);
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(adapter);
        return rootView;

    }
    // With the help of this method we are fetching categories from Category.json
    private void getCategory(){
        // It will Fetch json form Asset
        String jsonFileString = Utils.getJsonFromAssets(getActivity(),"Category.json");

        try{
            JSONObject mainJson = new JSONObject(jsonFileString);
            JSONArray jobArrayLatest = mainJson.getJSONArray("Category");
            //Iterating object and adding to arraylist
            for (int i = 0; i < jobArrayLatest.length(); i++) {
                JSONObject jsonObject = jobArrayLatest.getJSONObject(i);

                    CatItems objItem = new CatItems();
                    objItem.setCatId(jsonObject.getInt("CatId"));
                    objItem.setCatName(jsonObject.getString("CatName"));
                    objItem.setCatImgUrl(jsonObject.getString("CatImgUrl"));
                    mCatListItem.add(objItem);

            }


        }
        catch (Exception e){
            Utils.toast(getActivity(),e.toString());
        }


    }


}