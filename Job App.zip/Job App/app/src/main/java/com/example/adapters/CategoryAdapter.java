package com.example.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.college.londonjobs.R;
import com.example.items.CatItems;
import com.example.utils.RcyOnItemClick;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class CategoryAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private ArrayList<CatItems> dataList;
    private Context mContext;
    private RcyOnItemClick clickListener;

    public CategoryAdapter(Context context, ArrayList<CatItems> dataList) {
        this.dataList = dataList;
        this.mContext = context;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.cat_row_items, parent, false);

        return new CatItemHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        final CatItemHolder catHolder = (CatItemHolder) holder;
        final CatItems singleItem = dataList.get(position);
        catHolder.text.setText(singleItem.getCatName());
        Picasso.get().load(singleItem.getCatImgUrl()).placeholder(R.drawable.ic_launcher_background).into(catHolder.image);
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }


    class CatItemHolder extends RecyclerView.ViewHolder {
        ImageView image;
        TextView text;
        CardView lyt_parent;
        CatItemHolder(View itemView) {
            super(itemView);
            image = itemView.findViewById(R.id.image_cat);
            text = itemView.findViewById(R.id.cat_text);
            lyt_parent = itemView.findViewById(R.id.parentLayout);
        }
    }
}
