package com.example.fragments;

import android.content.Intent;
import android.os.Bundle;

import androidx.core.widget.NestedScrollView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.JsonReader;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.college.londonjobs.JobDetailActivity;
import com.college.londonjobs.R;
import com.example.adapters.HomeJobAdapter;
import com.example.items.ItmJobs;
import com.example.utils.RcyOnItemClick;
import com.example.utils.Utils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.Serializable;
import java.util.ArrayList;

import okhttp3.internal.Util;

public class HomeFragment extends Fragment {

    ProgressBar mProgressBar;
    LinearLayout layout_not_found;
    NestedScrollView nestedScrollView;
    TextView  latstViewAll;
    RecyclerView  rcvLatestJob;
    ArrayList<ItmJobs> jobLatstList;
    LinearLayout  layoutLatest;
    EditText etSearch;
    HomeJobAdapter latstAdapter;




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
       View rootView = inflater.inflate(R.layout.fragment_home,container,false);

        jobLatstList = new ArrayList<>();
        mProgressBar = rootView.findViewById(R.id.progBar1);
        layout_not_found = rootView.findViewById(R.id.layout_not_found);
        nestedScrollView = rootView.findViewById(R.id.nestedScrollView);
       // latstViewAll = rootView.findViewById(R.id.viewLatest);
        rcvLatestJob = rootView.findViewById(R.id.rcv_latest);
        layoutLatest = rootView.findViewById(R.id.layoutHomeLatest);
        etSearch = rootView.findViewById(R.id.edt_search);

        //setting recyclerview fixed size
        rcvLatestJob.setHasFixedSize(true);
        //Setting recyclerview vertical view
        rcvLatestJob.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        rcvLatestJob.setFocusable(false);
        rcvLatestJob.setNestedScrollingEnabled(false);
       getDetails();
       displayJobs();

       return rootView;

    }

    public void getDetails(){

        String jsonFileString = Utils.getJsonFromAssets(getActivity(),"Latest_Job.json");


        try{
            JSONObject mainJson = new JSONObject(jsonFileString);
            /*JSONObject jobAppJson = mainJson.getJSONObject("LONDON_JOB");*/
            JSONArray jobArrayLatest = mainJson.getJSONArray("latest_job");


            for (int i = 0; i < jobArrayLatest.length(); i++) {
                JSONObject jsonObject = jobArrayLatest.getJSONObject(i);

                ItmJobs objItem = new ItmJobs();
                objItem.setId(jsonObject.getString("id"));
                objItem.setJobName(jsonObject.getString("job_name"));
                objItem.setJobDesignation(jsonObject.getString("job_designation"));
                objItem.setJobSalary(jsonObject.getString("job_salary"));
                objItem.setJobCompanyName(jsonObject.getString("job_company_name"));
                objItem.setJobCompanyWebsite(jsonObject.getString("job_company_website"));
                objItem.setJobPhoneNumber(jsonObject.getString("job_phone_number"));
                objItem.setJobMail(jsonObject.getString("job_mail"));
                objItem.setJobVacancy(jsonObject.getString("job_vacancy"));
                objItem.setJobAddress(jsonObject.getString("job_address"));
                objItem.setJobQualification(jsonObject.getString("job_qualification"));
                objItem.setJobSkill(jsonObject.getString("job_skill"));
                objItem.setJobExperience(jsonObject.getString("job_experince"));
                objItem.setJobWorkDay(jsonObject.getString("job_work_day"));
                objItem.setJobWorkTime(jsonObject.getString("job_work_time"));
                objItem.setJobImage(jsonObject.getString("job_image"));
                objItem.setJobDate(jsonObject.getString("job_date"));
                objItem.setJobCategoryName(jsonObject.getString("category_name"));
                objItem.setJobFavourite(jsonObject.getBoolean("is_favourite"));

                jobLatstList.add(objItem);

            }




        }catch (Exception e){
            Utils.toast(getActivity(),e.toString());
        }




    }

    private void displayJobs(){
        if (!jobLatstList.isEmpty()) {
            latstAdapter = new HomeJobAdapter(getActivity(), jobLatstList);
            rcvLatestJob.setAdapter(latstAdapter);
            latstAdapter.setOnItemClickListener(new RcyOnItemClick() {
                @Override
                public void onItemClick(int position) {

                    Intent detailJobInt = new Intent(getActivity(), JobDetailActivity.class);
                    //detailJobInt.putExtra("sampleObject", jobLatstList.get(position));
                    startActivity(detailJobInt);
                }
            });


        } else {
            layoutLatest.setVisibility(View.GONE);
        }
    }



}