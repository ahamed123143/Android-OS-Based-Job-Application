package com.example.adapters;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.college.londonjobs.JobDetailActivity;
import com.college.londonjobs.R;
import com.example.items.ItmJobs;
import com.example.utils.RcyOnItemClick;
import com.example.utils.Utils;
import com.squareup.picasso.Picasso;

import java.io.Serializable;
import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;
import okhttp3.internal.Util;

public class HomeJobAdapter extends  RecyclerView.Adapter<RecyclerView.ViewHolder>{

    private ArrayList<ItmJobs> dataList;
    private Context mContext;
    private RcyOnItemClick clickListener;

    public HomeJobAdapter(Context context, ArrayList<ItmJobs> dataList) {
        this.dataList = dataList;
        this.mContext = context;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_job_itm, parent, false);
        return new ItemRowHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        final ItemRowHolder vwholder = (ItemRowHolder)holder;
        final ItmJobs singleItem = dataList.get(position);
        vwholder.jobTitle.setText(singleItem.getJobName());
        vwholder.jobType.setText(singleItem.getJobType());
        vwholder.jobAddress.setText(singleItem.getJobAddress());
        Picasso.get().load(singleItem.getJobImage()).placeholder(R.drawable.ic_launcher_background).into(vwholder.jobImage);

        vwholder.lyt_parent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                 //with the help of parcelable we are passing object from one activity to another activity
                Intent detailJobInt = new Intent(mContext, JobDetailActivity.class);
                detailJobInt.putExtra("detailItems",dataList.get(position));
                mContext.startActivity(detailJobInt);
            }
        });

    }

    @Override
    public int getItemCount() {
        return (null != dataList ? dataList.size() : 0);
    }

    public void setOnItemClickListener(RcyOnItemClick clickListener) {
        this.clickListener = clickListener;
    }
    class ItemRowHolder extends RecyclerView.ViewHolder {
        TextView jobTitle, jobAddress, jobType;
        LinearLayout lyt_parent;
        Button btnApplyJob;
        CardView cardViewType;
        CircleImageView jobImage;
        ImageView imageFav;

        ItemRowHolder(View itemView) {
            super(itemView);
            jobTitle = itemView.findViewById(R.id.text_job_title);
            jobType = itemView.findViewById(R.id.text_job_type);
            jobAddress = itemView.findViewById(R.id.text_job_address);
            lyt_parent = itemView.findViewById(R.id.rootLayout);
            cardViewType = itemView.findViewById(R.id.cardJobType);
            jobImage = itemView.findViewById(R.id.image_job);
            imageFav = itemView.findViewById(R.id.imageFav);
            btnApplyJob = itemView.findViewById(R.id.btn_apply_job);
        }
    }

}
