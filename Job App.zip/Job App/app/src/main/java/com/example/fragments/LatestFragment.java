package com.example.fragments;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.college.londonjobs.R;
import com.example.adapters.HomeJobAdapter;
import com.example.adapters.JobAdapter;
import com.example.items.ItmJobs;
import com.example.utils.Utils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

import okhttp3.internal.Util;


public class LatestFragment extends Fragment {

    ArrayList<ItmJobs> mListItem;
    public RecyclerView recyclerView;
    boolean isLatest = false;
    private ProgressBar progressBar;
    private LinearLayout lyt_not_found;
    boolean isFirst = true, isOver = false;
    private int pageIndex = 1;
    JobAdapter adapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.row_rcylview, container, false);

        if (getArguments() != null) {
            isLatest = getArguments().getBoolean("isLatest", false);
        }

        mListItem = new ArrayList<>();
        lyt_not_found = rootView.findViewById(R.id.lyt_not_found);
        progressBar = rootView.findViewById(R.id.progressBar);
        recyclerView = rootView.findViewById(R.id.vertical_courses_list);
        getDetails();
        displayData();
        recyclerView.setHasFixedSize(true);
        GridLayoutManager layoutManager = new GridLayoutManager(getContext(), 1);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setFocusable(false);
        return rootView;

    }

    public void getDetails(){

        String jsonFileString = Utils.getJsonFromAssets(getActivity(),"Latest_Job.json");


        try{
            Utils.toast(getActivity(),"Extracting Data");
            JSONObject mainJson = new JSONObject(jsonFileString);
            /*JSONObject jobAppJson = mainJson.getJSONObject("LONDON_JOB");*/
            JSONArray jobArrayLatest = mainJson.getJSONArray("latest_job");


            for (int i = 0; i < jobArrayLatest.length(); i++) {
                JSONObject jsonObject = jobArrayLatest.getJSONObject(i);

                ItmJobs objItem = new ItmJobs();
                objItem.setId(jsonObject.getString("id"));
                objItem.setJobName(jsonObject.getString("job_name"));
                objItem.setJobDesignation(jsonObject.getString("job_designation"));
                objItem.setJobSalary(jsonObject.getString("job_salary"));
                objItem.setJobCompanyName(jsonObject.getString("job_company_name"));
                objItem.setJobCompanyWebsite(jsonObject.getString("job_company_website"));
                objItem.setJobPhoneNumber(jsonObject.getString("job_phone_number"));
                objItem.setJobMail(jsonObject.getString("job_mail"));
                objItem.setJobVacancy(jsonObject.getString("job_vacancy"));
                objItem.setJobAddress(jsonObject.getString("job_address"));
                objItem.setJobQualification(jsonObject.getString("job_qualification"));
                objItem.setJobSkill(jsonObject.getString("job_skill"));
                objItem.setJobExperience(jsonObject.getString("job_experince"));
                objItem.setJobWorkDay(jsonObject.getString("job_work_day"));
                objItem.setJobWorkTime(jsonObject.getString("job_work_time"));
                objItem.setJobImage(jsonObject.getString("job_image"));
                objItem.setJobDate(jsonObject.getString("job_date"));
                objItem.setJobCategoryName(jsonObject.getString("category_name"));
                objItem.setJobFavourite(jsonObject.getBoolean("is_favourite"));

                mListItem.add(objItem);


            }
           // Utils.toast(getActivity(),Integer.toString(mListItem.size()));



        }catch (Exception e){
            Utils.toast(getActivity(),e.toString());
        }





    }
    //This method is use to display data in recyclerview
    private void displayData() {


           
            adapter = new JobAdapter(getActivity(), mListItem);
            recyclerView.setAdapter(adapter);

    }


}