package com.college.londonjobs;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.items.ItmJobs;
import com.example.utils.Utils;
import com.google.android.material.tabs.TabLayout;
import com.squareup.picasso.Picasso;

public class JobDetailActivity extends AppCompatActivity {

    ProgressBar mProgress;
    LinearLayout layout_not_found;
    ItmJobs jobObject;
    TextView jobsTitle, cmpnyTitle, jbDate, jbDesig, jbAddr, jbVacancy, jbPhn, jbMail, jbWeb,jbSalary;
    ImageView image_vw;
    Button buttonSave;
    Button buttonApplyJob;
    MyApplication MyApp;
    CoordinatorLayout lytParent;
    TabLayout tabsLayout;
    ViewPager viewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_job_detail);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        image_vw = findViewById(R.id.image_job);
        jobsTitle = findViewById(R.id.txt_job_title);
        cmpnyTitle = findViewById(R.id.txt_company_name);
        jbDate = findViewById(R.id.txt_job_date);
        jbDesig = findViewById(R.id.txt_job_desg);
        jbAddr = findViewById(R.id.txt_job_addrs);
        jbVacancy = findViewById(R.id.txt_vacn);
        jbPhn = findViewById(R.id.txt_phone_number);
        jbMail = findViewById(R.id.txt_email_addrs);
        jbWeb = findViewById(R.id.txt_web);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        //Receving object from another activity
       ItmJobs detailItems = getIntent().getParcelableExtra("detailItems");
       String imageUri = detailItems.getJobImage().replace("\\","");
       Picasso.get().load(imageUri).placeholder(R.drawable.ic_launcher_background).into(image_vw);
       jobsTitle.setText(detailItems.getJobName());
       cmpnyTitle.setText(detailItems.getJobCompanyName());
        jbDate.setText(detailItems.getJobDate());
        jbDesig.setText(detailItems.getJobDesignation());
        jbAddr.setText(detailItems.getJobAddress());
        jbVacancy.setText(detailItems.getJobVacancy());
        jbPhn.setText(detailItems.getJobPhoneNumber());
        jbMail.setText(detailItems.getJobMail());
        jbWeb.setText(detailItems.getJobCompanyWebsite());

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                break;
            default:
            return super.onOptionsItemSelected(item);

        }
        return true;
    }
}