package com.college.londonjobs;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.utils.Utils;
import com.example.utils.db.DatabaseHelper;
import com.example.items.SeekerUser;

public class RegisterSeekerActivity extends AppCompatActivity {

    EditText et_seeker_name;
    EditText et_seeker_email;
    EditText et_seeker_password;
    EditText et_seeker_phone;
    Button btn_seeker_login;
    Button btn_seeker_signUp;
    DatabaseHelper db;
    long result1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_seeker);
        db = new DatabaseHelper(this);
        btn_seeker_login = findViewById(R.id.btn_seeker_login);
        btn_seeker_signUp = (Button) findViewById(R.id.btn_seeker_signup);
        et_seeker_name = (EditText) findViewById(R.id.et_seeker_name);
        et_seeker_email = findViewById(R.id.et_seeker_email);
        et_seeker_password = findViewById(R.id.et_seeker_password);
        et_seeker_phone = findViewById(R.id.et_seeker_contact_no);

        btn_seeker_signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
             if(Utils.getEditText(et_seeker_name).isEmpty()){
                 et_seeker_name.setError("Please Enter Name");
             }
             else if(Utils.getEditText(et_seeker_email).isEmpty()){
                  et_seeker_email.setError("Email Cannot Be Empty");
             }
              else  if(!Utils.isEmailValid(Utils.getEditText(et_seeker_email))){
                 et_seeker_email.setError("Enter Valid Email");
                }
              else if(Utils.getEditText(et_seeker_password).isEmpty()){
                  et_seeker_password.setError("Password Cannot Be Empty");
             }
              else if(Utils.getEditText(et_seeker_phone).isEmpty()){
                  et_seeker_phone.setError("Phone No Cannot Be Empty");
             }
              else{
                 SeekerUser addUser = new SeekerUser("seeker",Utils.getEditText(et_seeker_name),Utils.getEditText(et_seeker_email),Utils.getEditText(et_seeker_password),Utils.getEditText(et_seeker_phone));
                long count = db.addUser(addUser, getApplicationContext());
                if(count == -1){
                    Utils.toast(getApplicationContext(),"User Already Exists");
                }
                else{
                    Utils.toast(getApplicationContext(),"User Added Successfully");
                    Intent i = new Intent(getApplicationContext(),LoginActivity.class);
                    startActivity(i);
                    finish();
                }

                 /*try {
                     db.addUser(addUser, getApplicationContext());
                     Utils.toast(getApplicationContext(),"User Added");
                 }
                 catch (SQLiteConstraintException exception){
                     Utils.toast(getApplicationContext(),exception.toString());
                 }*/

             }
            }
        });

        btn_seeker_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i = new Intent(getApplicationContext(),LoginActivity.class);
                startActivity(i);
                finish();
               /* try {
                    Utils.toast(getApplicationContext(),db.getCount());


                }
                catch (Exception exception)
                {
                    Utils.toast(getApplicationContext(),exception.toString());
                }*/
            }
        });

    }
}