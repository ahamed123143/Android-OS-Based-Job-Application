package com.college.londonjobs;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;

public class MyApplication extends Application {

    private static MyApplication mInstance;
    public SharedPreferences preferences;
    public String prefName = "jobsapp";

    public MyApplication() {
        mInstance = this;
    }


    @Override
    public void onCreate() {
        super.onCreate();
    }

    public static synchronized MyApplication getInstance() {
        return mInstance;
    }

    public void saveIsLogin(boolean flag) {
        preferences = this.getSharedPreferences(prefName, 0);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean("IsLoggedIn", flag);
        editor.apply();
    }

    public boolean getIsLogin() {
        preferences = this.getSharedPreferences(prefName, 0);
        return preferences.getBoolean("IsLoggedIn", false);
    }

    public void saveIsJobProvider(boolean flag) {
        preferences = this.getSharedPreferences(prefName, 0);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean("IsJobProvider", flag);
        editor.apply();
    }

    public boolean getIsJobProvider() {
        preferences = this.getSharedPreferences(prefName, 0);
        return preferences.getBoolean("IsJobProvider", false);
    }

    public boolean saveLogin(int user_id, String user_name, String email, String userType) {
        preferences = this.getSharedPreferences(prefName, 0);
        SharedPreferences.Editor editor = preferences.edit();
        editor.clear();
        editor.putInt("user_id", user_id);
        editor.putString("user_name", user_name);
        editor.putString("email", email);
        editor.putString("user_type",userType);
        return editor.commit();
    }

    public boolean saveUsername(String username){
        preferences = this.getSharedPreferences(prefName, 0);
        SharedPreferences.Editor editor = preferences.edit();
        editor.clear();
        editor.putString("user_name", username);
        return editor.commit();
    }

    public String getUserType() {
        preferences = this.getSharedPreferences(prefName, 0);
        return preferences.getString("user_type", "");
    }

    public String getUserName() {
        preferences = this.getSharedPreferences(prefName, 0);
        return preferences.getString("user_name", "");
    }

    public String getUserEmail() {
        preferences = this.getSharedPreferences(prefName, 0);
        return preferences.getString("email", "");
    }
    public int getUserId() {
        preferences = this.getSharedPreferences(prefName, 0);
        return preferences.getInt("user_id", 500);
    }

}
