package com.college.londonjobs;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.Toast;

import com.example.utils.Utils;
import com.example.utils.network.NetworkUtils;

import java.security.Provider;

public class SplashActivity extends AppCompatActivity {

    private boolean mIsBackButtonPress;
    MyApplication MyApp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        MyApp = MyApplication.getInstance();
        if (NetworkUtils.isConnected(SplashActivity.this)) {
            splashScrn();
        } else {

        }

    }

    //This method is to display splash screen for 2 second and take it to Main activity
    private void splashScrn(){

        Handler handle = new Handler();
        handle.postDelayed(new Runnable() {
            @Override
            public void run() {
                if(!mIsBackButtonPress){

                    // Checking if user is already logged in thru shared preference
                    if(MyApp.getIsLogin()){

                        //Checking weather user is seeker or provider
                        Log.d("getType",MyApp.getUserType());
                        if(MyApp.getUserType().equals("seeker")){
                            Intent mainActivity = new Intent(getApplicationContext(),MainActivity.class);
                            startActivity(mainActivity);
                        }
                        else{
                            Intent providerActivity = new Intent(getApplicationContext(), ProviderMainActivity.class);
                            startActivity(providerActivity);
                        }
                    }
                    else {
                        Intent loginAcitivity = new Intent(getApplicationContext(), LoginActivity.class);
                        startActivity(loginAcitivity);
                    }

                }

            }
        }, 2000);

    }

    @Override
    public void onBackPressed() {
        mIsBackButtonPress = true;
        super.onBackPressed();
    }
}