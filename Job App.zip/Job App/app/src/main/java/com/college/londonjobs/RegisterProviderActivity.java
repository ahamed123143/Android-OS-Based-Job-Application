package com.college.londonjobs;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteConstraintException;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.utils.Utils;
import com.example.utils.db.DatabaseHelper;
import com.example.items.SeekerUser;

public class RegisterProviderActivity extends AppCompatActivity {

    EditText et_provider_name;
    Button btn_provider_login;
    EditText et_provider_email;
    EditText et_provider_password;
    EditText et_provider_phone;
    Button btn_provider_signUp;
    DatabaseHelper db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_provider);
        db = new DatabaseHelper(this);
        btn_provider_login = findViewById(R.id.btn_provider_login);
        btn_provider_signUp = (Button) findViewById(R.id.btn_provider_signup);
        et_provider_name = (EditText) findViewById(R.id.et_provider_name);
        et_provider_email = findViewById(R.id.et_provider_email);
        et_provider_password = findViewById(R.id.et_provider_password);
        et_provider_phone = findViewById(R.id.et_provider_contact_no);

        // By Clicking this button registering user as provider
        btn_provider_signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //checking username is not empty
                if(Utils.getEditText(et_provider_name).isEmpty()){
                    et_provider_name.setError("Please Enter Name");
                }
                //checking user email not empty
                else if(Utils.getEditText(et_provider_email).isEmpty()){
                    et_provider_email.setError("Email Cannot Be Empty");
                }
                //checking user Emails is in valid format
                else  if(!Utils.isEmailValid(Utils.getEditText(et_provider_email))){
                    et_provider_email.setError("Enter Valid Email");
                }
                //checking user password is not empty
                else if(Utils.getEditText(et_provider_password).isEmpty()){

                    et_provider_password.setError("Password Cannot Be Empty");
                }
                //checking user phone no is not empty
                else if(Utils.getEditText(et_provider_phone).isEmpty()){
                    et_provider_phone.setError("Phone No Cannot Be Empty");
                }
                else{
                    //Registering User As Provider
                    SeekerUser addUser = new SeekerUser("provider",Utils.getEditText(et_provider_name),Utils.getEditText(et_provider_email),Utils.getEditText(et_provider_password),Utils.getEditText(et_provider_phone));
                    long count = db.addUser(addUser, getApplicationContext());
                    if(count == -1){
                        Utils.toast(getApplicationContext(),"User Already Exists");
                    }
                    else{
                        Utils.toast(getApplicationContext(),"User Added Successfully");
                        Intent i = new Intent(getApplicationContext(),LoginActivity.class);
                        startActivity(i);
                        finish();
                    }
                }
            }
        });

        btn_provider_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i = new Intent(getApplicationContext(),LoginActivity.class);
                startActivity(i);
                finish();
            }
        });

    }
}