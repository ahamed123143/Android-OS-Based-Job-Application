package com.college.londonjobs;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Database;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.items.SeekerUser;
import com.example.utils.Utils;
import com.example.utils.db.DatabaseHelper;

import java.util.ArrayList;

public class ProfileEditingActivity extends AppCompatActivity {

    EditText et_username,et_emailAddress,et_password, et_phoneNo, et_city,et_address,et_companyName, et_experience;
    TextView txt_username, txt_company_name, txt_experience,txt_phone,txt_gender,txt_skill,txt_skillBtn,txt_email;
    Button btn_save;
    DatabaseHelper db;
    MyApplication MyApp;
    SeekerUser userDetails;
    String userEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_editing);
        MyApp = MyApplication.getInstance();
        userEmail = MyApp.getUserEmail();
        db = new DatabaseHelper(this);
        btn_save = findViewById(R.id.btn_save);
        et_username = findViewById(R.id.edt_name);
        et_emailAddress = findViewById(R.id.edt_email);
        et_password = findViewById(R.id.edt_password);
        et_phoneNo = findViewById(R.id.edt_phone);
        et_city = findViewById(R.id.edt_city);
        et_address = findViewById(R.id.edt_address);
        et_companyName = findViewById(R.id.et_company_name);
        et_experience = findViewById(R.id.edt_experience);


        txt_username = findViewById(R.id.txtUserName);
        txt_email = findViewById(R.id.txtEmail);
        txt_company_name = findViewById(R.id.txtCompany);
        txt_experience = findViewById(R.id.txtUserExp);
        txt_phone = findViewById(R.id.txtPhone);
        txt_gender = findViewById(R.id.txt_gender);
        txt_skill = findViewById(R.id.txt_skills);
        txt_skillBtn = findViewById(R.id.txt_add_skills_btn);

       userDetails = db.getUserDetails(userEmail,getApplicationContext());
       //Fetching username  from database and and displaying in profile
       if(userDetails.getUsername()!=null){
           txt_username.setText("Name:"+userDetails.getUsername());
       }
        //Fetching Email  from database and and displaying in profile
       if(userDetails.getEmail()!=null){
           txt_email.setText("Email:"+userDetails.getEmail());
       }
        if(userDetails.getExperience()!=null){
            txt_email.setText("Experience:"+userDetails.getExperience());
        }
        if(userDetails.getPhone()!=null){
            txt_email.setText("Phone No:"+userDetails.getPhone());
        }
        if(userDetails.getGender()!=null){
            txt_email.setText("Gender:"+userDetails.getGender());
        }


        btn_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                buttonClick();
            }
        });






    }

    public void buttonClick(){
        //Updating Username from profile page
        if(!et_username.getText().toString().equals("")){
            try {
                db.updateUsername(et_username.getText().toString(), userEmail);
                refreshActivity();
                et_username.setText("");
            }
            catch (Exception e){
                Log.d("Update Username",e.toString());
            }

        }
       else if(!et_username.getText().toString().equals("")){
            try {
                db.updateUsername(et_username.getText().toString(), userEmail);
                refreshActivity();
                et_username.setText("");
            }
            catch (Exception e){
                Log.d("Update Username",e.toString());
            }

        }

    }

    public void refreshActivity(){
        finish();
        startActivity(getIntent());
    }
}