package com.college.londonjobs;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.CursorIndexOutOfBoundsException;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.utils.Utils;
import com.example.utils.db.DatabaseHelper;
import com.example.items.SeekerUser;

import java.security.Provider;

import okhttp3.internal.Util;


public class LoginActivity extends AppCompatActivity  {

    Button btn_register_seeker;
    Button btn_register_provider;
    Button btn_login;
    EditText et_email;
    EditText et_password;
    String email;
    DatabaseHelper db;
    SharedPreferences sharedPreferences;
    MyApplication MyApp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        MyApp = MyApplication.getInstance();
        db = new DatabaseHelper(this);
        btn_login = findViewById(R.id.btn_login);
        et_email = (EditText) findViewById(R.id.edt_email_login);
        et_password = (EditText)findViewById(R.id.edt_password_login);
        btn_register_seeker = (Button)findViewById(R.id.btn_job_seeker);
        btn_register_provider = findViewById(R.id.btn_job_provider);
        sharedPreferences = this.getSharedPreferences("London Jobs",0);

        // By clicking this  button user go to Seeker registration activity
        btn_register_seeker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(),RegisterSeekerActivity.class);
                startActivity(i);

            }
        });
        //By clicking this button user go to Provider registration activity
        btn_register_provider.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(),RegisterProviderActivity.class);
                startActivity(i);

            }
        });
        // Authenticate user and validate login
        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                       if(Utils.getEditText(et_email).isEmpty() || !Utils.isEmailValid(Utils.getEditText(et_email))) {
                           et_email.setError("Please Enter Correct Email");
                       }
                       else if (Utils.getEditText(et_password).isEmpty()){
                           et_password.setError("Password Cannot Be Empty");
                       }
                       else {
                           try {
                               SeekerUser userDetails = db.getUserDetails(Utils.getEditText(et_email), getApplicationContext());
                               String email = Utils.getEditText(et_email);
                               String password = Utils.getEditText(et_password);
                               if(userDetails.getEmail().equals(email) && userDetails.getPassword().equals(password)){
                                   MyApp.saveLogin(userDetails.getId(),userDetails.getUsername(),userDetails.getEmail(),userDetails.getUsertype());
                                   MyApp.saveIsLogin(true);

                                   Intent i = new Intent(getApplicationContext(),MainActivity.class);
                                   startActivity(i);
                               }
                               else{
                                   Utils.toast(getApplicationContext(),"Please Enter Correct Username/Password");
                               }



                           }catch (CursorIndexOutOfBoundsException exception){
                               Toast.makeText(getApplicationContext(),"Email Address is Not Valid",Toast.LENGTH_SHORT).show();
                               et_email.setText("");
                               et_password.setText("");
                               et_email.requestFocus();
                           }


                       }
                   }




        });



   }


}